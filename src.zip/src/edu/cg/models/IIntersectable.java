package edu.cg.models;

import java.util.List;


public interface IIntersectable {
	/** 
	 * 
	 * @return
	 */
	public BoundingSphereTree getBoundingSpheres();
	

}
